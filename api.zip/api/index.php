<!DOCTYPE html>
<html>
<head>
    <title>API Kedai Ramen</title>
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container text-center mt-5">
    <h1 class="mb-4">API Kedai Ramen</h1>

    <div class="d-grid gap-2 col-6 mx-auto">
    <a href="account.php" class="btn btn-success">Akun</a>
    <a href="product.php" class="btn btn-primary">Produk</a>
</div>

</div>

</body>
</html>
