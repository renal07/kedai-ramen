<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include '../config.php';

$makanan = $_POST['makanan'] ?? '';
$harga = $_POST['harga'] ?? '';
$deskripsi = $_POST['deskripsi'] ?? '';
$gambar = '';

// Validasi data dasar
if (empty($makanan) || empty($harga) || empty($deskripsi)) {
    echo json_encode(["error" => "Field tidak boleh kosong"]);
    exit;
}

// Proses gambar dari file atau link
if (!empty($_FILES['gambar_file']['name'])) {
    $namaFile = basename($_FILES['gambar_file']['name']);
    $targetDir = "../uploads/";
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    $targetPath = $targetDir . $namaFile;

    if (move_uploaded_file($_FILES['gambar_file']['tmp_name'], $targetPath)) {
        $gambar = "uploads/" . $namaFile;
    }
} elseif (!empty($_POST['gambar_text'])) {
    $gambar = $_POST['gambar_text'];
} else {
    echo json_encode(["error" => "Gambar tidak ditemukan"]);
    exit;
}

// Insert ke database
$query = "INSERT INTO produk (makanan, gambar, harga, deskripsi) VALUES (?, ?, ?, ?)";
$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "ssds", $makanan, $gambar, $harga, $deskripsi);

if (mysqli_stmt_execute($stmt)) {
    echo json_encode(["message" => "Produk berhasil ditambahkan."]);
} else {
    echo json_encode(["error" => "Gagal insert: " . mysqli_error($koneksi)]);
}
?>
